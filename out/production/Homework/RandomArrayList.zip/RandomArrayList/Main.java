package RandomArrayList;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RandowArayList randowArayList =new RandowArayList();
        randowArayList.getRandomElement();
    }
}
